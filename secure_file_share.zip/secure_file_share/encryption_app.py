import tkinter as tk
from tkinter import filedialog, messagebox
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from pathlib import Path

class EncryptionApp:
    def __init__(self, master):
        master.title("File Encryption/Decryption App")
        master.geometry("400x200")

        self.create_folders()

        self.private_key_path = Path('keys/private.pem')
        self.public_key_path = Path('keys/public.pem')

        self.generate_keys_button = tk.Button(master, text="Generate Keys", command=self.generate_keys)
        self.generate_keys_button.pack()

        self.encrypt_button = tk.Button(master, text="Encrypt File", command=self.encrypt_file)
        self.encrypt_button.pack()

        self.decrypt_button = tk.Button(master, text="Decrypt File", command=self.decrypt_file)
        self.decrypt_button.pack()

    def create_folders(self):
        folders = ['keys', 'encrypted_files', 'decrypted_files']
        for folder in folders:
            if not Path(folder).exists():
                Path(folder).mkdir()

    def generate_keys(self):
        try:
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=2048,
                backend=default_backend()
            )

            public_key = private_key.public_key()

            with open(self.private_key_path, 'wb') as key_file:
                key_file.write(private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                ))

            with open(self.public_key_path, 'wb') as key_file:
                key_file.write(public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ))

            messagebox.showinfo("Key Generation", "Key pair generated successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Key generation failed: {e}")

    def load_private_key(self):
        try:
            with open(self.private_key_path, 'rb') as key_file:
                private_key = serialization.load_pem_private_key(
                    key_file.read(),
                    password=None,
                    backend=default_backend()
                )
            return private_key
        except Exception as e:
            messagebox.showerror("Error", f"Private key loading failed: {e}")
            return None

    def load_public_key(self):
        try:
            with open(self.public_key_path, 'rb') as key_file:
                public_key = serialization.load_pem_public_key(
                    key_file.read(),
                    backend=default_backend()
                )
            return public_key
        except Exception as e:
            messagebox.showerror("Error", f"Public key loading failed: {e}")
            return None

    def encrypt_file(self):
        try:
            file_path = filedialog.askopenfilename(title="Select a file to encrypt")
            if file_path:
                with open(file_path, 'rb') as file:
                    data = file.read()

                public_key = self.load_public_key()

                if public_key:
                    original_extension = Path(file_path).suffix
                    encrypted_data = self.encrypt_blob(data, public_key, original_extension)

                    encrypted_file_path = Path("encrypted_files") / (Path(file_path).stem + ".enc")
                    with open(encrypted_file_path, 'wb') as encrypted_file:
                        encrypted_file.write(encrypted_data)

                    messagebox.showinfo("Encryption", f"File encrypted successfully.\nEncrypted file saved in 'encrypted_files' folder.")
        except Exception as e:
            messagebox.showerror("Error", f"Encryption failed: {e}")

    def encrypt_blob(self, blob, public_key, original_extension):
        try:
            # Store the original extension along with the encrypted data
            encrypted_data = original_extension.encode() + public_key.encrypt(
                blob,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return encrypted_data
        except Exception as e:
            messagebox.showerror("Error", f"Encryption failed: {e}")
            return None

    def decrypt_file(self):
        try:
            encrypted_file_path = filedialog.askopenfilename(title="Select a file to decrypt")
            if encrypted_file_path:
                with open(encrypted_file_path, 'rb') as file:
                    encrypted_data = file.read()

                private_key = self.load_private_key()

                if private_key:
                    decrypted_data, original_extension = self.decrypt_blob(encrypted_data, private_key)
                    if decrypted_data:
                        self.save_decrypted_file(decrypted_data, encrypted_file_path, original_extension)
        except Exception as e:
            messagebox.showerror("Error", f"Decryption failed: {e}")

    def decrypt_blob(self, encrypted_blob, private_key):
        try:
            # Extract the original extension from the encrypted data
            original_extension = encrypted_blob[:4].decode()
            decrypted_data = private_key.decrypt(
                encrypted_blob[4:],
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return decrypted_data, original_extension
        except Exception as e:
            messagebox.showerror("Error", f"Decryption failed: {e}")
            return None, None

    def save_decrypted_file(self, decrypted_data, original_file_path, original_extension):
        try:
            decrypted_file_path = Path("decrypted_files") / (Path(original_file_path).stem + "_decrypted" + original_extension)
            with open(decrypted_file_path, 'wb') as decrypted_file:
                decrypted_file.write(decrypted_data)

            messagebox.showinfo("Decryption", f"File decrypted successfully.\nDecrypted file saved in 'decrypted_files' folder.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save decrypted file: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = EncryptionApp(root)
    root.mainloop()
